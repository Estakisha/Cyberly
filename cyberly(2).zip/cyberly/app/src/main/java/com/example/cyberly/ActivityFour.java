package com.example.cyberly;



import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityFour extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_four);

        ListView listView = findViewById(R.id.developers);

        // Load names from strings.xml
        String[] names = getResources().getStringArray(R.array.developers);

        // Set adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, names);

        listView.setAdapter(adapter);
    }
}