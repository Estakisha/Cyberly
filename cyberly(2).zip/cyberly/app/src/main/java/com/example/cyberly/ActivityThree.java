package com.example.cyberly;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityThree extends AppCompatActivity {

    private CheckBox[] checkBoxes;
    private TextView tvResult;
    private Button btnCalculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_three);

        // checkboxes object (15) make sure its 15
        checkBoxes = new CheckBox[]{
                findViewById(R.id.checkBox1),
                findViewById(R.id.checkBox2),
                findViewById(R.id.checkBox3),
                findViewById(R.id.checkBox4),
                findViewById(R.id.checkBox5),
                findViewById(R.id.checkBox6),
                findViewById(R.id.checkBox7),
                findViewById(R.id.checkBox8),
                findViewById(R.id.checkBox9),
                findViewById(R.id.checkBox10),
                findViewById(R.id.checkBox11),
                findViewById(R.id.checkBox12),
                findViewById(R.id.checkBox13),
                findViewById(R.id.checkBox14),
                findViewById(R.id.checkBox15)
        };

        tvResult = findViewById(R.id.tvResult);
        btnCalculate = findViewById(R.id.btnCalculate);

        btnCalculate.setOnClickListener(v -> calculateScore());
    }

    private void calculateScore() {
        int total = checkBoxes.length;
        int checkedCount = 0;

        for (CheckBox cb : checkBoxes) {
            if (cb.isChecked()) {
                checkedCount++;
            }
        }

        tvResult.setText("You follow " + checkedCount + " out of " + total + " cybersecurity advices.");
    }
}