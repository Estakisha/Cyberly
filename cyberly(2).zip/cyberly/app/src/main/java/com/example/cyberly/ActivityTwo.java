package com.example.cyberly;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityTwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);

        //  1
        ImageButton btn1 = findViewById(R.id.btnIcon1);
        TextView textDetails1 = findViewById(R.id.textDetails1);

        btn1.setOnClickListener(v -> {
            int visibility = textDetails1.getVisibility();
            textDetails1.setVisibility(visibility == View.VISIBLE ? View.GONE : View.VISIBLE);
        });

        // 2
        ImageButton btn2 = findViewById(R.id.btnIcon2);
        TextView textDetails2 = findViewById(R.id.textDetails2);

        btn2.setOnClickListener(v -> {
            int visibility = textDetails2.getVisibility();
            textDetails2.setVisibility(visibility == View.VISIBLE ? View.GONE : View.VISIBLE);
        });

        // 3
        ImageButton btn3 = findViewById(R.id.btnIcon3);
        TextView textDetails3 = findViewById(R.id.textDetails3);

        btn3.setOnClickListener(v -> {
            int visibility = textDetails3.getVisibility();
            textDetails3.setVisibility(visibility == View.VISIBLE ? View.GONE : View.VISIBLE);
        });

        // 4
        ImageButton btn4 = findViewById(R.id.btnIcon4);
        TextView textDetails4 = findViewById(R.id.textDetails4);

        btn4.setOnClickListener(v -> {
            int visibility = textDetails4.getVisibility();
            textDetails4.setVisibility(visibility == View.VISIBLE ? View.GONE : View.VISIBLE);
        });

        // 5
        ImageButton btn5 = findViewById(R.id.btnIcon5);
        TextView textDetails5 = findViewById(R.id.textDetails5);

        btn5.setOnClickListener(v -> {
            int visibility = textDetails5.getVisibility();
            textDetails5.setVisibility(visibility == View.VISIBLE ? View.GONE : View.VISIBLE);
        });











    }
}