package com.example.cyberly;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ActivityOne extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one);

        // Button 1 and Text 1
        Button button1 = findViewById(R.id.button1);
        TextView text1 = findViewById(R.id.text1);
        button1.setOnClickListener(v -> {
            text1.setVisibility(text1.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        });

        // Button 2 and Text 2
        Button button2 = findViewById(R.id.button2);
        TextView text2 = findViewById(R.id.text2);
        button2.setOnClickListener(v -> {
            text2.setVisibility(text2.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        });

        // Button 3 and Text 3
        Button button3 = findViewById(R.id.button3);
        TextView text3 = findViewById(R.id.text3);
        button3.setOnClickListener(v -> {
            text3.setVisibility(text3.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        });

        // Button 4 and Text 4
        Button button4 = findViewById(R.id.button4);
        TextView text4 = findViewById(R.id.text4);
        button4.setOnClickListener(v -> {
            text4.setVisibility(text4.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        });


        // Button 5 and Text 5
        Button button5 = findViewById(R.id.button5);
        TextView text5 = findViewById(R.id.text5);
        button5.setOnClickListener(v -> {
            text5.setVisibility(text5.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        });


    }
}
